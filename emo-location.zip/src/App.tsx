/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Battery, Signal, Wifi } from 'lucide-react';
import { motion } from 'motion/react';

export default function App() {
  return (
    <div className="relative h-screen w-full overflow-hidden bg-sky-300 font-sans text-white">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1513002749550-c59d786b8e6c?q=80&w=2574&auto=format&fit=crop"
          alt="Blue sky with clouds"
          className="h-full w-full object-cover"
          referrerPolicy="no-referrer"
        />
        {/* Overlay gradient for better text readability if needed, keeping it subtle */}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-white/10" />
      </div>

      {/* Status Bar (Simulated) */}
      <div className="absolute top-0 left-0 right-0 z-50 flex items-center justify-between px-6 py-3 text-black">
        <span className="text-sm font-semibold">9:41</span>
        <div className="flex items-center gap-1.5">
          <Signal className="h-4 w-4 fill-current" />
          <Wifi className="h-4 w-4" />
          <Battery className="h-4 w-4 fill-current" />
        </div>
      </div>

      {/* Top Logo */}
      <div className="absolute top-0 left-0 right-0 z-40 flex justify-center pt-3">
        <span className="font-script text-2xl text-black">emo</span>
      </div>

      {/* Main Content */}
      <main className="relative z-10 flex h-full flex-col items-center justify-center px-4">
        
        {/* Location Badge */}
        <motion.div 
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="relative mb-2 flex flex-col items-center"
        >
          <div className="relative flex items-center justify-center rounded-[3rem] bg-white px-8 py-6 shadow-lg sm:px-12 sm:py-10">
             {/* Slight arch effect using CSS transform if desired, but keeping it clean for now */}
            <h1 className="font-display text-6xl tracking-tighter text-[#5B9BD5] sm:text-8xl">
              LOCATION
            </h1>
          </div>
        </motion.div>

        {/* Subtitle */}
        <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="mt-4"
        >
            <span className="font-sans text-sm text-white/80">by </span>
            <span className="font-script text-xl text-white">emo</span>
        </motion.div>

      </main>

      {/* Footer Actions */}
      <div className="absolute bottom-0 left-0 right-0 z-20 flex flex-col items-center pb-8 px-6">
        <p className="mb-6 text-center text-xs font-medium text-gray-600/80 mix-blend-multiply">
          By tapping "Get me in" you're<br />
          accepting the <span className="underline decoration-gray-600/50 underline-offset-2">terms</span>.
        </p>

        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="w-full max-w-xs rounded-full bg-gradient-to-r from-[#4A6FFF] to-[#5C5CFF] py-4 text-lg font-semibold text-white shadow-lg shadow-blue-500/30 transition-all hover:shadow-blue-500/40 active:shadow-blue-500/20"
        >
          Get me in
        </motion.button>

        {/* Home Indicator */}
        <div className="mt-6 h-1 w-32 rounded-full bg-black/20" />
      </div>
    </div>
  );
}
